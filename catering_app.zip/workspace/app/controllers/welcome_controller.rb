class WelcomeController < ApplicationController
  def index
  end

  def about
  end

  def menu
  end

  def reviews
  end
end
